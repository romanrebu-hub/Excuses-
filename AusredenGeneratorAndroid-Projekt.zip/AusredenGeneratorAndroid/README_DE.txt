AUSREDEN-GENERATOR – ANDROID-PROJEKT

Hinweis:
Dieses Paket ist ein Android-Studio-Projekt, keine bereits kompilierte APK.
In der aktuellen Arbeitsumgebung sind die Android-Buildwerkzeuge nicht installiert.

APK erstellen:
1. Installiere Android Studio auf einem Windows-, Mac- oder Linux-Computer.
2. Entpacke diese ZIP-Datei.
3. Öffne Android Studio und wähle "Open" / "Öffnen".
4. Wähle den entpackten Ordner "AusredenGeneratorAndroid".
5. Warte, bis Gradle synchronisiert hat. Beim ersten Mal wird eine Internetverbindung benötigt.
6. Wähle Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Android Studio zeigt nach erfolgreichem Build einen Link zum APK-Ordner an.

Die App enthält die 50 Ausreden, einen Zufallsgenerator und eine Kopierfunktion.
Sie benötigt keine Internetberechtigung und lädt die HTML-Datei lokal aus der App.
